<?php

class Fooman_EmailAttachments_Model_Core_Email_Queue
    extends Fooman_EmailAttachments_Model_Core_Email_Queue_Compatibility
{

}
